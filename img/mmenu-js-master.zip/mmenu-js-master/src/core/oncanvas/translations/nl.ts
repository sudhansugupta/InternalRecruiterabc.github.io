export default {
	'Menu': 'Menu'
};