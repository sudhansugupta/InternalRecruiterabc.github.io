export default {
	'Menu': 'Menu'
};
