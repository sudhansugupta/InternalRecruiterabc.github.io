import Mmenu from '../../core/oncanvas/mmenu.oncanvas';

export default function(
	this : Mmenu
) {
	this.conf.classNames.selected = 'active';
};
