export default {
    Search: 'Buscar',
    'No results found.': 'Nenhum resultado encontrado.',
    cancel: 'cancelar'
};
