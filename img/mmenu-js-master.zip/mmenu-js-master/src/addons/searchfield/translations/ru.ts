export default {
    Search: 'Найти',
    'No results found.': 'Ничего не найдено.',
    cancel: 'отменить'
};
